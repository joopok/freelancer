export interface Category {
  id: number;
  name: string;
  count: number;
  tab: string;
  bgGradient: string;
}
